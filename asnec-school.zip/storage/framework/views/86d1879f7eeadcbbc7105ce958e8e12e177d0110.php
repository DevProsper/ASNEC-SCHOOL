<div class="row p-4 pt-5">
    <div class="col-12">
        <div class="callout callout-info">
            <div class="row">
                <div class="col-md-12">
                    <h5><i class="fas fa-search"></i> Recherche par par classe et année scolaire </h5>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par classe</label>
                        <select class="form-control" wire:model="selectedClasse">
                            <option value="">Toutes les classes </option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par année scolaire</label>
                        <select class="form-control" wire:model="selectedAnneeScolaire">
                            <option value="">Toutes les années scolaires</option>
                            <?php $__currentLoopData = $anneesscolaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anneeScolaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($anneeScolaire->id); ?>" <?php if($anneeScolaire->id === $anneeScolaireParDefaut): ?> selected <?php endif; ?>>
                                <?php echo e($anneeScolaire->nom); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-gradient-primary d-flex align-items-center">
                <h3 class="card-title flex-grow-1"><i class="fa fa-calendar-plus fa-2x"></i> Emplois du temps</h3>

                <div class="card-tools d-flex align-items-center ">
                    <a class="btn btn-success text-white mr-4 d-block" wire:click.prevent="goToAddEmploisDuTemps()"><i
                            class="fa fa-calendar-plus"></i>Nouvel emplois du temps</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0 table-striped" style="height: 100%;">
                <table class="table table-head-fixed">
                    <thead>
                        <tr>
                            <th style="width:14%;">Heure</th>
                            <th style="width:10%;">Lundi</th>
                            <th style="width:10%;">Mardi</th>
                            <th style="width:10%;">Mercredi</th>
                            <th style="width:10%;">Jeudi</th>
                            <th style="width:10%;">Vendredi</th>
                            <th style="width:10%;">Samedi</th>
                            <th style="width:10%;">Dimamnche</th>
                            <th style="width:30%;" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $emplois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->heure); ?></td>
                            <td><?php echo e(isset($value->matierej1) ? $value->matiere1->nom : "----"); ?></td>
                            <td><?php echo e(isset($value->matierej2) ? $value->matiere2->nom : "----"); ?></td>
                            <td><?php echo e(isset($value->matierej3) ? $value->matiere3->nom : "----"); ?></td>
                            <td><?php echo e(isset($value->matierej4) ? $value->matiere4->nom : "----"); ?></td>
                            <td><?php echo e(isset($value->matierej5) ? $value->matiere5->nom : "----"); ?></td>
                            <td><?php echo e(isset($value->matierej6) ? $value->matiere6->nom : "----"); ?></td>
                            <td><?php echo e(isset($value->matierej7) ? $value->matiere7->nom : "----"); ?></td>
                            <td class="text-center">
                                <button class="btn btn-link" wire:click="goToEditEmplois(<?php echo e($value->id); ?>)"> <i class="far fa-edit"></i> </button>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("utilisateurs")): ?>
                                <button class="btn btn-link" wire:click="confirmDelete('<?php echo e($value->nom); ?>', <?php echo e($value->id); ?>)">
                                    <i class="far fa-trash-alt"></i> </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <div class="float-right">
                </div>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/emploisdutemps/liste.blade.php ENDPATH**/ ?>