<div class="row p-4 pt-5">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-gradient-primary d-flex align-items-center">
                <h3 class="card-title flex-grow-1"><i class="fa fa-calendar-plus fa-2x"></i> Liste des enseignants</h3>
                <div class="card-tools d-flex align-items-center ">
                    <a class="btn btn-success text-white mr-4 d-block" wire:click.prevent="goToAddEnseignant()"><i
                        class="fa fa-calendar-plus"></i> Créer un nouveau</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0 table-striped" style="height: 300px;">
                <table class="table table-head-fixed">
                    <thead>
                        <tr>
                            <th style="width:25%;">Genre</th>
                            <th style="width:25%;">Nom complet</th>
                            <th style="width:20%;">Teléphone</th>
                            <th style="width:20%;">Diplôme</th>
                            <th style="width:30%;" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($value->sexe == "F"): ?>
                                <img src="<?php echo e(asset('assets/images/woman.png')); ?>" width="24" />
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/man.png')); ?>" width="24" />
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($value->nom); ?> <?php echo e($value->prenom); ?></td>
                            <td><?php echo e($value->telephone1); ?> </td>
                            <td><?php echo e($value->diplome->nom); ?> </td>
                            <td class="text-center">
                                <button class="btn btn-link" wire:click="goToEditEnseignant(<?php echo e($value->id); ?>)"> <i
                                        class="far fa-edit"></i> </button>
                                <button class="btn btn-link"
                                    wire:click="confirmDelete('<?php echo e($value->nom); ?>', <?php echo e($value->id); ?>)">
                                    <i class="far fa-trash-alt"></i> </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <div class="float-right">
                    <?php echo e($enseignants->links()); ?>

                </div>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/enseignants/liste.blade.php ENDPATH**/ ?>