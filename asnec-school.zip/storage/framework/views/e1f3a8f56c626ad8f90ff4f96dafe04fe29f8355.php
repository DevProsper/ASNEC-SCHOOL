<div class="row p-4 pt-5">
    <div class="col-md-9">
        <!-- general form elements -->
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user-plus fa-2x"></i> Formulaire d'édition utilisateur</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form" wire:submit.prevent="updateMatiere()" method="POST">
                <div class="card-body">

                    <div class="d-flex">
                        <div class="form-group flex-grow-1 mr-2">
                            <label>Matière</label>
                            <input autocomplete="off" type="text" wire:model="editMatiere.nom"
                                class="form-control <?php $__errorArgs = ['editMatiere.nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    
                            <?php $__errorArgs = ["editMatiere.nom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="d-flex">
                        <div class="form-group flex-grow-1 mr-2">
                            <label>Nom court</label>
                            <input autocomplete="off" type="text" wire:model="editMatiere.nomCourt"
                                class="form-control <?php $__errorArgs = ['editMatiere.nomCourt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    
                            <?php $__errorArgs = ["editMatiere.nomCourt"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="d-flex">
                        <div class="form-group flex-grow-1 mr-2">
                            <label>Coefficient</label>
                            <input autocomplete="off" type="text" wire:model="editMatiere.coefficient"
                                class="form-control <?php $__errorArgs = ['editMatiere.coefficient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    
                            <?php $__errorArgs = ["editMatiere.coefficient"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Appliquer les modifications</button>
                    <button type="button" wire:click="goToListMatiere()" class="btn btn-danger">Retouner à la liste des
                        matières</button>
                </div>
            </form>
        </div>
        <!-- /.card -->

    </div>
</div>

<div class="col-md-12 mt-4">
    <div class="card card-primary">
        <div class="card-header d-flex align-items-center">
            <h3 class="card-title flex-grow-1"><i class="fas fa-fingerprint fa-2x"></i> Attributions aux classes</h3>
            <button class="btn bg-gradient-success" wire:click="updateMatieresAndClasses"><i class="fas fa-check"></i>
                Appliquer les modifications</button>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div id="accordion">
                <?php $__currentLoopData = $assignClasses["classes"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4 class="card-title flex-grow-1">
                            <a data-parent="#accordion" href="#" aria-expanded="true">
                                <?php echo e($classe["classe_nom"]); ?>

                            </a>
                        </h4>
                        <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success">
        
                            <input type="checkbox" class="custom-control-input"
                                wire:model.lazy="assignClasses.classes.<?php echo e($loop->index); ?>.active" <?php if($classe["active"]): ?> checked
                                <?php endif; ?> id="customSwitch<?php echo e($classe['classe_id']); ?>">
                            <label class="custom-control-label" for="customSwitch<?php echo e($classe['classe_id']); ?>"> <?php echo e($classe["active"]? "Activé" : "Desactivé"); ?></label>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/administrations/matieres/edit.blade.php ENDPATH**/ ?>