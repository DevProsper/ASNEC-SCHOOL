<div class="row p-4 pt-5">
    <div class="col-12">
        <div class="callout callout-info">
            <div class="row">
                <div class="col-md-12">
                    <h5><i class="fas fa-search"></i> Recherche avancée des élèves </h5>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par année scolaire</label>
                        <select class="form-control" wire:model="anneeScolaire">
                            <option value="">Toutes les années scolaires</option>
                            <?php $__currentLoopData = $anneesscolaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anneeScolaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($anneeScolaire->id); ?>" <?php if($anneeScolaire->id === $anneeScolaireParDefaut): ?>
                                selected <?php endif; ?>>
                                <?php echo e($anneeScolaire->nom); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par classes</label>
                        <select class="form-control" wire:model="classe">
                            <option value="">Toutes les classes</option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par sexe</label>
                        <select class="form-control" wire:model="sexe">
                            <option value="">Les deux</option>
                            <option value="H">Masculin</option>
                            <option value="F">Féminin</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="container">
                <div class="col-md-6">
                </div>
                <div class="col-md-6">
                    <p><?php echo e($totalAdmissions); ?> élèves trouvé(e)s.</p>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-gradient-primary d-flex align-items-center">
                <h3 class="card-title flex-grow-1"><i class="fas fa-users"></i> Liste des élèves en attente d'admission
                    à l'école</h3>
                <div class="card-tools d-flex align-items-center ">
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Tel</th>
                            <th>Classe</th>
                            <th>Admission</th>
                            <th>Date admission</th>
                            <th>Statut</th>
                            <th>Année scolaire</th>
                            <th class="text-center">Paiement(s)</th>
                            <!-- Autres colonnes d'information des admissions -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($admission->eleve->sexe == "F"): ?>
                                <img src="<?php echo e(asset('assets/images/woman.png')); ?>" width="24" />
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/man.png')); ?>" width="24" />
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($admission->eleve->nom); ?> <?php echo e($admission->eleve->prenom); ?></td>
                            <td><?php echo e($admission->eleve->telephone); ?></td>
                            <td><?php echo e($admission->classe->nom); ?></td>
                            <td><?php echo e($admission->tarification->categorie->nom); ?></td>
                            <td><?php echo e(substr($admission->created_at, 0, 10)); ?></td>
                            <?php if($admission->statutAdmission == "Nouveau"): ?>
                            <td><span class="badge bg-info">Nouveau(lle)</span></td>
                            <?php else: ?>
                            <td><span class="badge bg-danger">Redoublant(e)</span></td>
                            <?php endif; ?>
                            <td><?php echo e($admission->anneesscolaire->nom); ?></td>

                            <td class="text-center">
                                <button class="btn btn-primary" wire:click="goToEditEvaluation(<?php echo e($admission->id); ?>)">
                                    <i class="fa-solid fa-bolt">F</i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
            <div class="card-footer">
                <div class="float-right">

                </div>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/evaluations/liste.blade.php ENDPATH**/ ?>