<div class="row p-4 pt-5">
    <div class="col-12">
        <div class="callout callout-info">
          <div class="row">
                <div class="col-md-12">
                    <h5><i class="fas fa-search"></i> Recherche avancée des opérations </h5>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par année scolaire</label>
                        <select class="form-control" wire:model="anneeScolaire">
                            <option value="">Toutes les années scolaires</option>
                            <?php $__currentLoopData = $anneesscolaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anneeScolaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($anneeScolaire->id); ?>" <?php if($anneeScolaire->id === $anneeScolaireParDefaut): ?> selected <?php endif; ?>>
                                <?php echo e($anneeScolaire->nom); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Filtrer par catégorie tarif</label>
                        <select class="form-control" wire:model="categorieTarificationFilter">
                            <option value="">Toutes les catégories</option>
                            <?php $__currentLoopData = $categoriesTarification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label>Filtrer par catégorie</label>
                        <select class="form-control" wire:model="statutFilter" id="statut">
                            <option value="">Toutes les opérations</option>
                            <option value="1">Soldées</option>
                            <option value="2">Acomptes</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label>Filtrer par mois</label>
                        <select class="form-control" wire:model="periodeFilter" id="periode">
                            <option value="">Tous</option>
                            <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($periode->id); ?>"><?php echo e($periode->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label>Filtrer par classe</label>
                        <select class="form-control" wire:model="classeId" id="periode">
                            <option value="">Tous</option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="row">
            <div class="container">
                <div class="col-md-6">
                </div>
                <div class="col-md-6">
                    <p>Requêtes trouvées : <?php echo e($operations->count()); ?></p>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-gradient-primary d-flex align-items-center">
                <h3 class="card-title flex-grow-1"><i class="fas fa-users"></i> Liste des élèves en attente d'admission à l'école</h3>
                <div class="card-tools d-flex align-items-center ">
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <tr>
                        <th>#</th>
                        <th style="width:15%;">Eleve</th>
                        <th>Classe</th>
                        <th>Libelle</th>
                        <th style="width:5%;">Prix</th>
                        <th style="width:10%;">Scolaire</th>
                        <th>Période</th>
                        <th>Montant versé</th>
                        <th>Montant Restant</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($value->eleve->sexe == "F"): ?>
                                <img src="<?php echo e(asset('assets/images/woman.png')); ?>" width="24" />
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/man.png')); ?>" width="24" />
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($value->eleve->nom); ?> <?php echo e($value->eleve->prenom); ?></td>
                            <td><?php echo e($value->admission->classe->nom); ?></td>
                            <td><?php echo e($value->tarification->nom); ?></td>
                            <td><b><?php echo e(Money($value->tarification->prix)); ?></b></td>
                            <td><?php echo e($value->anneesscolaire->nom); ?></td>
                            <?php if($value->periode_id): ?>
                                <td><?php echo e($value->periode->nom); ?></td>
                            <?php else: ?>
                            <td>-----</td>
                            <?php endif; ?>
                            <td><?php echo e(Money($value->montantVerse)); ?></td>
                            <?php if($value->montantRestant): ?>
                            <td><span class="badge bg-danger"><?php echo e((Money($value->montantRestant))); ?></span></td>
                            <?php else: ?>
                            <td><span class="badge bg-primary">Soldé</span></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
            <div class="card-footer">
                <div class="float-right">
                    <?php echo e($operations->links()); ?>

                </div>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/operations/liste.blade.php ENDPATH**/ ?>