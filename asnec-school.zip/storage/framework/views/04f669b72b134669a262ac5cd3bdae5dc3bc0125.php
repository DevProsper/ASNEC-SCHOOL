<div class="row p-4 pt-5">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-gradient-primary d-flex align-items-center">
                <h3 class="card-title flex-grow-1"><i class="fas fa-users"></i> 
                    Liste des élèves en attente d'admission à l'école</h3>
                <div class="card-tools d-flex align-items-center ">
                    <div class="card-tools d-flex align-items-center ">
                    </div>
                </div>
                <div class="card-tools d-flex align-items-center ">
                    <div class="input-group input-group-md" style="width: 370px;">
                        <input type="text" name="table_search" wire:model.debounce.700ms="search"
                            class="form-control float-right" placeholder="Recherche par nom ou tel (Eleve ou titeur)">

                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width:5%;">#</th>
                            <th style="width:20%;">Nom complet</th>
                            <th style="width:10%;">Teléphone</th>
                            <th style="width:5%;">Statut</th>
                            <th style="width:20%;">Titeur</th>
                            <th style="width:5%;">Téléphone</th>
                            <th style="width:20%;" class="text-center">Inscription-Réinscription</th>
                            <th style="width:20%;" class="text-center">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($value->sexe == "F"): ?>
                                <img src="<?php echo e(asset('assets/images/woman.png')); ?>" width="24" />
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/man.png')); ?>" width="24" />
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($value->nom); ?> <?php echo e($value->prenom); ?></td>
                            <td><?php echo e($value->telephone); ?></td>
                            <?php if($value->defaut == 1): ?>
                            <td><span class="badge bg-info">Non Inscrit(e)</span></td>
                            <?php else: ?>
                            <td><span class="badge bg-warning">Déjà inscrit(e) - Ancien(e)</span></td>
                            <?php endif; ?>
                            <td><?php echo e($value->nomTiteur); ?> <?php echo e($value->prenomTiteur); ?></td>
                            <td><?php echo e($value->telephoneTiteur); ?></td>
                            <td class="text-center">
                                <button class="btn btn-link" wire:click="goToshowAdmission(<?php echo e($value->id); ?>)"> 
                                    <b>Inscription/Réinscription</b>
                                </button>
                            </td>
                            <td><?php echo e($value->created_at->diffForHumans()); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
            <div class="card-footer">
                <div class="float-right">
                    <?php echo e($eleves->links()); ?>

                </div>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/caisses/liste.blade.php ENDPATH**/ ?>