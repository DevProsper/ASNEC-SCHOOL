<div wire:ignore.self>

    <?php if($currentPage == PAGECREATEFORM): ?>
    <?php echo $__env->make("livewire.modules.administrations.batiments.create", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($currentPage == PAGEEDITFORM): ?>
    <?php echo $__env->make("livewire.modules.administrations.batiments.edit", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($currentPage == PAGELIST): ?>
    <?php echo $__env->make("livewire.modules.administrations.batiments.liste", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>

<script>
    window.addEventListener("showSuccessMessage", event=>{
        Swal.fire({
                position: 'top-end',
                icon: 'success',
                toast:true,
                title: event.detail.message || "Opération effectuée avec succès!",
                showConfirmButton: false,
                timer: 5000
                }
            )
    })
</script>

<script>
    window.addEventListener("showErrorMessage", event=>{
        Swal.fire({
                position: 'top-end',
                icon: 'warning',
                toast:true,
                title: event.detail.message || "Opération effectuée avec succès!",
                showConfirmButton: false,
                timer: 5000
                }
            )
    })
</script>

<script>
    window.addEventListener("showConfirmMessage", event=>{
       Swal.fire({
        title: event.detail.message.title,
        text: event.detail.message.text,
        icon: event.detail.message.type,
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Continuer',
        cancelButtonText: 'Annuler'
        }).then((result) => {
        if (result.isConfirmed) {
            if(event.detail.message.data){
                window.livewire.find('<?php echo e($_instance->id); ?>').deleteBatiment(event.detail.message.data.data_id)
            }
        }
        })
    })

</script><?php /**PATH C:\xampp\htdocs\asnec-school\resources\views/livewire/modules/administrations/batiments/index.blade.php ENDPATH**/ ?>